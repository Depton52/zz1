﻿#version 150

// â”€â”€ Among Us smooth fog override â€” distance 6 â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// One pack per view distance (build.ps1 stamps 6 for each tier). The
// plugin sends each player the tier matching their effective vision distance, so
// the world fades to fog color exactly at their view radius (no hard block wall,
// no pop-in). Keep the tier distances in sync with the hidePlayer radii in
// VisionSystem so the fog edge lines up with where players actually vanish.
//
// The fog end is CLAMPED, not hard-set: end = min(fogEnd, 6). That lets
// vanilla effects that shorten fog (Blindness during a lights-out sabotage) pull
// vision *below* the cap with no pack swap, while normal play (huge render-distance
// fogEnd) is capped at 6.
//
// VERSION NOTE: these function signatures match ~1.21.2â€“1.21.5. Mojang reworked
// fog into a uniform buffer in 1.21.6+, so on 1.21.8 the vanilla fog.glsl may look
// different. If so: extract the real fog.glsl from the 1.21.8 client jar
// (assets/minecraft/shaders/include/fog.glsl), paste it into template/ unchanged,
// then apply the same clamp â€” min(fogEnd, 6) â€” and rebuild.

const float FOG_END_OVERRIDE = 6.0;  // this tier's view distance in blocks
const float FOG_START_FRAC   = 0.7;           // fog begins at 70% of the end distance

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd) {
    float end = min(fogEnd, FOG_END_OVERRIDE);
    float start = end * FOG_START_FRAC;
    if (vertexDistance <= start) {
        return 0.0;
    } else if (vertexDistance >= end) {
        return 1.0;
    }
    return (vertexDistance - start) / (end - start);
}

vec4 apply_fog(vec4 inColor, float vertexDistance, float fogStart, float fogEnd, vec4 fogColor) {
    float fogValue = linear_fog_value(vertexDistance, fogStart, fogEnd);
    return vec4(mix(inColor.rgb, fogColor.rgb, fogValue * fogColor.a), inColor.a);
}
