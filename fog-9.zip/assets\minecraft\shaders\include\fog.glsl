﻿#version 150

// â”€â”€ Among Us smooth fog override â€” distance 9 â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// This is the vanilla 1.21.8 fog.glsl with ONE addition: total_fog_value mixes in
// a hardcoded radial (spherical) fog that reaches full opacity at 9
// blocks, so the world fades to fog color exactly at this tier's view radius
// regardless of the client's render distance. build.ps1 stamps 9 per tier;
// the plugin sends each player the tier matching their vision.
//
// Because total_fog_value takes a max(), the NEARER fog always wins â€” so vanilla
// effects that shorten fog (Blindness during a lights-out sabotage) still darken
// the screen below this cap with no pack swap.
//
// If a future MC update changes fog.glsl, re-extract it from the client jar and
// re-apply the two marked lines below.

layout(std140) uniform Fog {
    vec4 FogColor;
    float FogEnvironmentalStart;
    float FogEnvironmentalEnd;
    float FogRenderDistanceStart;
    float FogRenderDistanceEnd;
    float FogSkyEnd;
    float FogCloudsEnd;
};

// â”€â”€ Among Us: this tier's hard view-distance cap, in blocks â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const float AU_FOG_END = 9.0;
const float AU_FOG_START = AU_FOG_END * 0.7; // fog begins at 70% of the cap

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd) {
    if (vertexDistance <= fogStart) {
        return 0.0;
    } else if (vertexDistance >= fogEnd) {
        return 1.0;
    }

    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd) {
    float vanilla = max(linear_fog_value(sphericalVertexDistance, environmentalStart, environmantalEnd), linear_fog_value(cylindricalVertexDistance, renderDistanceStart, renderDistanceEnd));
    // â”€â”€ Among Us: force full fog at the tier cap (nearer fog wins) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    float capped = linear_fog_value(sphericalVertexDistance, AU_FOG_START, AU_FOG_END);
    return max(vanilla, capped);
}

vec4 apply_fog(vec4 inColor, float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd, vec4 fogColor) {
    float fogValue = total_fog_value(sphericalVertexDistance, cylindricalVertexDistance, environmentalStart, environmantalEnd, renderDistanceStart, renderDistanceEnd);
    return vec4(mix(inColor.rgb, fogColor.rgb, fogValue * fogColor.a), inColor.a);
}

float fog_spherical_distance(vec3 pos) {
    return length(pos);
}

float fog_cylindrical_distance(vec3 pos) {
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}
